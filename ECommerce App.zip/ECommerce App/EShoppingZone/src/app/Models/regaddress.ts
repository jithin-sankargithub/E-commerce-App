export interface Iaddress {
    houseNumber:string;
    street:string;
    city:string;
    state:string;
    pincode:string;

}
