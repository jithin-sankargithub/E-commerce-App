// import { ComponentFixture, TestBed } from '@angular/core/testing';
// import { RouterTestingModule } from '@angular/router/testing';
// import { HttpClientTestingModule } from '@angular/common/http/testing'
// import { MerchantComponent } from './merchant.component';
// import { MatDialog } from '@angular/material/dialog';
// import { Overlay } from '@angular/cdk/overlay';
// import { InjectionToken } from '@angular/core';

// describe('MerchantComponent', () => {
//   let component: MerchantComponent;
//   let fixture: ComponentFixture<MerchantComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       imports:[ HttpClientTestingModule,
//         RouterTestingModule],
//       declarations: [ MerchantComponent ],
//       providers :[MatDialog,Overlay,InjectionToken]
//     })
//     .compileComponents();
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(MerchantComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
